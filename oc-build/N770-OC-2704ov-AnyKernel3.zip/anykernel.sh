### AnyKernel3 Ramdisk Mod Script
## N770 Exynos9810 big-cluster overclock (2314 MHz) - kernel swap only

### AnyKernel setup
# global properties
properties() { '
kernel.string=N770 Exynos9810 OC 2704MHz +OV (big cluster, 2652+50mV 2704+75mV) by Claude/Soretake
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=r7
device.name2=r7q
device.name3=SM-N770F
device.name4=r7s
device.name5=
supported.versions=
supported.patchlevels=
supported.vendorpatchlevels=
'; } # end properties

### AnyKernel install
## boot files attributes
boot_attributes() {
set_perm_recursive 0 0 755 644 $RAMDISK/*;
set_perm_recursive 0 0 750 750 $RAMDISK/init* $RAMDISK/sbin;
} # end attributes

# boot shell variables
BLOCK=/dev/block/by-name/boot;
IS_SLOT_DEVICE=0;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=auto;

# import functions/variables and setup patching - see for reference (DO NOT REMOVE)
. tools/ak3-core.sh;

# boot install: replace only the kernel, keep the stock ramdisk + header
dump_boot;
write_boot;
## end boot install
